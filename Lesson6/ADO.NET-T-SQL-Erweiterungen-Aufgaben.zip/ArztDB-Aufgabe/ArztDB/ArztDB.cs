﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Data;

namespace ArztDB
{
    public class ArztDB
    {        
        #region Fields
        /// <summary>
        /// Connectstring from config file
        /// </summary>
        private static string _connectionString = Properties.Settings.Default.ConnectionString;

        #endregion
        

        #region Methoden 
 
        /// <summary>
        /// Scores berechnen
        /// </summary>
        /// <param name="z1">Zahl 1</param>
        /// <param name="z2">Zahl 2</param>
        /// <param name="z3">Zahl 3</param>
        /// <param name="z4">Zahl 4</param>
        /// <param name="z5">Zahl 4</param>
        /// <returns></returns>
   
        public static int Scores(int z1, int z2, int z3, int z4, int z5)
        {
            int result = 0;

            // ...

            return result;
        }

        /// <summary>
        /// Ermittelt die Anzahl der Konsultationen einer Diagnose
        /// </summary>
        /// <param name="diagnose">name der diagnose</param>
        /// <returns>Anzahl Konsultationen</returns>
        public static int GetNumKonsultation(string diagnose)
        {
            int result = 0;

            // ...

            return result;
        }

        /// <summary>
        /// Arztliste anzeigen
        /// </summary>
        /// <returns>dataset</returns>
        public static DataSet ArztListe()
        {
            DataSet ds = new DataSet();

            // ...

            return ds;
        }

        /// <summary>
        /// PLZ einfügen
        /// </summary>
        /// <param name="plz">PLZ</param>
        /// <param name="ort">Ort</param>
        /// <returns></returns>
        public static bool InsertOrt(int plz, string ort)
        {
            bool result = false;

            // ...

            return result;
        }

        public static DataSet PlzListe()
        {
            DataSet ds = new DataSet();

            // ...

            return ds;
        }

        #endregion
    }
}
