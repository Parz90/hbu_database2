﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ArztDB
{
    public partial class A1Form : Form
    {
        public A1Form()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Init
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void A1Form_Load(object sender, EventArgs e)
        {
            // Felder in Standardwerten vorbelegen
        }

        /// <summary>
        /// Stored procedure aufrufen
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnCalc_Click(object sender, EventArgs e)
        {
            // Methode scores() aufrufen
        }

    }
}
