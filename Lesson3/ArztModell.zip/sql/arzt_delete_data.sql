/* ---------------------------------------------------------------------- */
/* Script generated with: DeZign for Databases V7.2.0                     */
/* Target DBMS:           MS SQL Server 2012                              */
/* Project file:          ArztDatenbank.dez                               */
/* Project name:                                                          */
/* Author:                                                                */
/* Script type:           Database drop script                            */
/* Created on:            2014-12-06 15:06                                */
/* ---------------------------------------------------------------------- */

-- Delete all data
delete from [Konsultation];
delete from [Diagnose];
delete from [Arzt];
delete from [Patient];
delete from [Ort];
